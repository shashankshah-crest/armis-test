"""
Azure Function entry point for Armis Alerts Data Collector.
"""
import time
import azure.functions as func
from ..SharedCode.logger import applogger
from ..SharedCode.consts import LOGS_STARTS_WITH, MAX_EXECUTION_TIME
from .alerts_collector import AlertsCollector


def main(mytimer: func.TimerRequest) -> None:
    """
    Main entry point for Armis Alerts Data Collector.
    
    Args:
        mytimer: Timer trigger request
    """
    start_time = time.time()
    function_name = "AlertsDataCollector"
    
    applogger.info(f"{LOGS_STARTS_WITH} {function_name}: Function execution started")
    
    try:
        # Check if timer is past due
        if mytimer.past_due:
            applogger.warning(f"{LOGS_STARTS_WITH} {function_name}: Timer is past due!")
        
        # Initialize and run collector
        collector = AlertsCollector(start_time)
        collector.process_alerts()
        
        # Calculate execution time
        execution_time = time.time() - start_time
        applogger.info(
            f"{LOGS_STARTS_WITH} {function_name}: "
            f"Function execution completed successfully. Time taken: {execution_time:.2f} seconds"
        )
        
    except Exception as error:
        execution_time = time.time() - start_time
        applogger.error(
            f"{LOGS_STARTS_WITH} {function_name}: "
            f"Function execution failed after {execution_time:.2f} seconds. Error: {error}"
        )
        raise
