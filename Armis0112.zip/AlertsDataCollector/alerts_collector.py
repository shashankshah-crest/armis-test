"""
Business logic for collecting Armis alerts and ingesting to Sentinel.
"""
import time
import json
import inspect
from datetime import datetime, timedelta
from ..SharedCode.logger import applogger
from ..SharedCode.consts import (
    LOGS_STARTS_WITH,
    TABLE_NAME,
    AZURE_DCR_RULE_ID,
    MAX_EXECUTION_TIME,
    BATCH_SIZE,
    MAX_INGESTION_SIZE_MB
)
from ..SharedCode.armis_client import ArmisClient
from ..SharedCode.sentinel import MicrosoftSentinel
from ..SharedCode.state_manager import StateManager
from ..SharedCode.exceptions import (
    ArmisDataConnectorException,
    ArmisAPIRequestException,
    ArmisDataIngestionException
)


class AlertsCollector:
    """
    Collects alerts from Armis API and ingests them to Microsoft Sentinel.
    """
    
    def __init__(self, start_time: float):
        """
        Initialize AlertsCollector.
        
        Args:
            start_time: Function start time for timeout management
        """
        self.logs_starts_with = f"{LOGS_STARTS_WITH} AlertsCollector:"
        self.start_time = start_time
        self.checkpoint_key = "alerts_last_timestamp"
        
        # Initialize components
        self.armis_client = ArmisClient()
        self.sentinel_client = MicrosoftSentinel()
        self.state_manager = StateManager()
        
        applogger.info(f"{self.logs_starts_with} Initialized successfully")
    
    def _check_timeout(self) -> bool:
        """
        Check if approaching timeout limit.
        
        Returns:
            True if should stop execution, False otherwise
        """
        elapsed_time = time.time() - self.start_time
        if elapsed_time >= MAX_EXECUTION_TIME:
            applogger.warning(
                f"{self.logs_starts_with} Approaching timeout limit. "
                f"Elapsed time: {elapsed_time:.2f}s"
            )
            return True
        return False
    
    def _get_last_checkpoint(self) -> dict:
        """
        Retrieve last checkpoint from state manager.
        
        Returns:
            Dictionary containing checkpoint data
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint = self.state_manager.get(self.checkpoint_key)
            
            if checkpoint:
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Retrieved checkpoint: {checkpoint}"
                )
                return checkpoint
            else:
                # No checkpoint found, start from 24 hours ago
                default_time = (datetime.utcnow() - timedelta(hours=24)).isoformat() + "Z"
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"No checkpoint found. Starting from: {default_time}"
                )
                return {"last_timestamp": default_time, "last_alert_id": None}
                
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to retrieve checkpoint: {error}"
            )
            # Return default checkpoint on error
            default_time = (datetime.utcnow() - timedelta(hours=24)).isoformat() + "Z"
            return {"last_timestamp": default_time, "last_alert_id": None}
    
    def _save_checkpoint(self, last_timestamp: str, last_alert_id: str = None):
        """
        Save checkpoint to state manager.
        
        Args:
            last_timestamp: Last processed timestamp
            last_alert_id: Last processed alert ID
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_data = {
                "last_timestamp": last_timestamp,
                "last_alert_id": last_alert_id,
                "updated_at": datetime.utcnow().isoformat() + "Z"
            }
            
            self.state_manager.post(self.checkpoint_key, checkpoint_data)
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Checkpoint saved: {checkpoint_data}"
            )
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to save checkpoint: {error}"
            )
            # Don't raise exception, just log the error
    
    def _transform_alert(self, alert: dict) -> dict:
        """
        Transform Armis alert to Sentinel format.
        
        Args:
            alert: Raw alert from Armis API
            
        Returns:
            Transformed alert for Sentinel
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            # Extract key fields from alert
            transformed = {
                "TimeGenerated": alert.get("time", datetime.utcnow().isoformat() + "Z"),
                "AlertId": str(alert.get("alertId", "")),
                "Title": alert.get("title", ""),
                "Description": alert.get("description", ""),
                "Severity": alert.get("severity", ""),
                "Status": alert.get("status", ""),
                "Type": alert.get("type", ""),
                "ActivityUUIDs": json.dumps(alert.get("activityUUIDs", [])),
                "DeviceIds": json.dumps(alert.get("deviceIds", [])),
                "ConnectionIds": json.dumps(alert.get("connectionIds", [])),
                "AlertIdStr": alert.get("alertIdStr", ""),
                "RiskLevel": alert.get("riskLevel", ""),
                "RiskLevelInt": alert.get("riskLevelInt", 0),
                "RiskLevelStr": alert.get("riskLevelStr", ""),
                "RiskLevelText": alert.get("riskLevelText", ""),
                "RiskScore": alert.get("riskScore", 0),
                "RiskScoreStr": alert.get("riskScoreStr", ""),
                "RiskScoreText": alert.get("riskScoreText", ""),
                "RiskScoreInt": alert.get("riskScoreInt", 0),
                "RiskScoreValue": alert.get("riskScoreValue", 0),
                "RiskScoreValueStr": alert.get("riskScoreValueStr", ""),
                "RiskScoreValueText": alert.get("riskScoreValueText", ""),
                "RiskScoreValueInt": alert.get("riskScoreValueInt", 0),
                "RawData": json.dumps(alert)
            }
            
            # Validate cell sizes (25KB limit)
            for key, value in transformed.items():
                if isinstance(value, str):
                    value_size = len(value.encode('utf-8'))
                    if value_size > 25 * 1024:  # 25KB
                        applogger.warning(
                            f"{self.logs_starts_with}(method={__method_name}) "
                            f"Field '{key}' exceeds 25KB limit. Truncating..."
                        )
                        # Truncate to 25KB
                        transformed[key] = value[:25000] + "...[TRUNCATED]"
            
            return transformed
            
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to transform alert: {error}"
            )
            raise
    
    def _ingest_alerts(self, alerts: list):
        """
        Ingest alerts to Microsoft Sentinel.
        
        Args:
            alerts: List of transformed alerts
        """
        __method_name = inspect.currentframe().f_code.co_name
        
        if not alerts:
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) No alerts to ingest")
            return
        
        try:
            # Chunk data based on size limit
            chunks = self.sentinel_client.chunk_data(alerts, MAX_INGESTION_SIZE_MB)
            
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Ingesting {len(alerts)} alerts in {len(chunks)} chunks"
            )
            
            # Ingest each chunk
            for i, chunk in enumerate(chunks):
                if self._check_timeout():
                    applogger.warning(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        f"Timeout approaching. Stopping ingestion at chunk {i+1}/{len(chunks)}"
                    )
                    break
                
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Ingesting chunk {i+1}/{len(chunks)} with {len(chunk)} alerts"
                )
                
                self.sentinel_client.post_data(
                    events=chunk,
                    table_name=TABLE_NAME,
                    dcr_rule_id=AZURE_DCR_RULE_ID
                )
                
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Successfully ingested chunk {i+1}/{len(chunks)}"
                )
            
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to ingest alerts: {error}"
            )
            raise ArmisDataIngestionException(f"Failed to ingest alerts: {error}")
    
    def process_alerts(self):
        """
        Main processing method to fetch and ingest alerts.
        """
        __method_name = inspect.currentframe().f_code.co_name
        
        try:
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Starting alert processing")
            
            # Get last checkpoint
            checkpoint = self._get_last_checkpoint()
            last_timestamp = checkpoint.get("last_timestamp")
            
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Fetching alerts from: {last_timestamp}"
            )
            
            # Fetch alerts from Armis API
            current_time = datetime.utcnow().isoformat() + "Z"
            raw_alerts = self.armis_client.get_alerts(
                from_time=last_timestamp,
                to_time=current_time
            )
            
            if not raw_alerts:
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    "No new alerts found"
                )
                return
            
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Fetched {len(raw_alerts)} alerts from Armis API"
            )
            
            # Transform alerts
            transformed_alerts = []
            for alert in raw_alerts:
                if self._check_timeout():
                    applogger.warning(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        "Timeout approaching. Stopping transformation."
                    )
                    break
                
                try:
                    transformed = self._transform_alert(alert)
                    transformed_alerts.append(transformed)
                except Exception as error:
                    applogger.error(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        f"Failed to transform alert {alert.get('alertId', 'unknown')}: {error}"
                    )
                    # Continue with next alert
                    continue
            
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Transformed {len(transformed_alerts)} alerts"
            )
            
            # Ingest alerts to Sentinel
            if transformed_alerts:
                self._ingest_alerts(transformed_alerts)
                
                # Save checkpoint with latest timestamp
                latest_alert = max(
                    transformed_alerts,
                    key=lambda x: x.get("TimeGenerated", "")
                )
                latest_timestamp = latest_alert.get("TimeGenerated", current_time)
                latest_alert_id = latest_alert.get("AlertId")
                
                self._save_checkpoint(latest_timestamp, latest_alert_id)
                
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Successfully processed {len(transformed_alerts)} alerts"
                )
            else:
                applogger.warning(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    "No alerts were successfully transformed"
                )
            
        except ArmisAPIRequestException as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"API request failed: {error}"
            )
            raise
        except ArmisDataIngestionException as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Data ingestion failed: {error}"
            )
            raise
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Alert processing failed: {error}"
            )
            raise ArmisDataConnectorException(f"Alert processing failed: {error}")
