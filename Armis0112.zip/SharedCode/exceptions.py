"""
Custom exception classes for Armis Data Connector.
"""


class ArmisDataConnectorException(Exception):
    """Base exception for Armis Data Connector."""
    pass


class ArmisAPIAuthenticationException(ArmisDataConnectorException):
    """Exception raised for authentication failures with Armis API."""
    pass


class ArmisAPIRateLimitException(ArmisDataConnectorException):
    """Exception raised when Armis API rate limit is exceeded."""
    pass


class ArmisAPIRequestException(ArmisDataConnectorException):
    """Exception raised for general API request failures."""
    pass


class ArmisInvalidResponseException(ArmisDataConnectorException):
    """Exception raised when API response is invalid or unexpected."""
    pass


class ArmisDataIngestionException(ArmisDataConnectorException):
    """Exception raised when data ingestion to Sentinel fails."""
    pass


class ArmisCheckpointException(ArmisDataConnectorException):
    """Exception raised for checkpoint management failures."""
    pass


class ArmisConfigurationException(ArmisDataConnectorException):
    """Exception raised for configuration or environment variable issues."""
    pass
