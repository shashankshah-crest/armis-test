"""
Constants and environment variables for Armis Data Connector.
"""
import os

# Armis API Configuration
ARMIS_API_URL = os.environ.get("ArmisBaseURL", "")
ARMIS_API_SECRET_KEY = os.environ.get("ArmisAPISecretKey", "")

# Azure Sentinel Configuration
AZURE_CLIENT_ID = os.environ.get("AZURE_CLIENT_ID", "")
AZURE_CLIENT_SECRET = os.environ.get("AZURE_CLIENT_SECRET", "")
AZURE_TENANT_ID = os.environ.get("AZURE_TENANT_ID", "")
AZURE_DATA_COLLECTION_ENDPOINT = os.environ.get("AZURE_DATA_COLLECTION_ENDPOINT", "")
AZURE_DCR_RULE_ID = os.environ.get("AZURE_DATA_COLLECTION_RULE_ID", "")

# Table Configuration
TABLE_NAME = os.environ.get("TableName", "ArmisAlerts")

# Azure Storage Configuration (for checkpoints)
AZURE_STORAGE_CONNECTION_STRING = os.environ.get("AzureWebJobsStorage", "")
CHECKPOINT_TABLE_NAME = "ArmisCheckpoints"

# Logging Configuration
LOG_LEVEL = os.environ.get("LogLevel", "INFO")
DEFAULT_LOG_LEVEL = "INFO"
LOGS_STARTS_WITH = "Armis"

# API Configuration
MAX_TIMEOUT = 120
MAX_RETRIES = 3
RETRY_STATUS_CODES = [429, 500, 503, 401]
NO_RETRY_STATUS_CODES = [400, 403, 404, 409]

# Pagination Configuration
MAX_PAGE_SIZE = 1000
DEFAULT_PAGE_SIZE = 500

# Execution Configuration
MAX_EXECUTION_TIME = 570  # 9.5 minutes (Azure Functions 10-min limit)
BATCH_SIZE = 100

# Data Limits
MAX_INGESTION_SIZE_MB = 25  # 25MB buffer (30MB limit)
MAX_CELL_SIZE_KB = 25  # 25KB buffer (30KB limit)

# Schedule Configuration
SCHEDULE = os.environ.get("Schedule", "0 */10 * * * *")  # Every 10 minutes

# Scope for Azure Gov Cloud support
SCOPE = os.environ.get("Scope", "https://monitor.azure.com")

# Error Messages
ERROR_MISSING_ENV_VARS = "Missing required environment variables: {}"
ERROR_API_AUTHENTICATION = "Failed to authenticate with Armis API"
ERROR_API_REQUEST = "Failed to fetch data from Armis API"
ERROR_DATA_INGESTION = "Failed to ingest data to Azure Sentinel"
ERROR_CHECKPOINT = "Failed to manage checkpoint"
