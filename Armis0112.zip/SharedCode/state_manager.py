"""
State management for checkpoints using Azure Table Storage.
"""
import json
import inspect
from datetime import datetime
from azure.data.tables import TableServiceClient, TableClient
from azure.core.exceptions import ResourceNotFoundError, ResourceExistsError
from .logger import applogger
from .consts import LOGS_STARTS_WITH, AZURE_STORAGE_CONNECTION_STRING, CHECKPOINT_TABLE_NAME
from .exceptions import ArmisCheckpointException


class StateManager:
    """
    Manages checkpoint state using Azure Table Storage.
    """
    
    def __init__(self, connection_string: str = None, table_name: str = None):
        """
        Initialize StateManager.
        
        Args:
            connection_string: Azure Storage connection string
            table_name: Name of the table for checkpoints
        """
        self.logs_starts_with = f"{LOGS_STARTS_WITH} StateManager:"
        self.connection_string = connection_string or AZURE_STORAGE_CONNECTION_STRING
        self.table_name = table_name or CHECKPOINT_TABLE_NAME
        
        try:
            self.table_service_client = TableServiceClient.from_connection_string(
                self.connection_string
            )
            self._ensure_table_exists()
            self.table_client = self.table_service_client.get_table_client(self.table_name)
        except Exception as error:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to initialize StateManager: {error}"
            )
            raise ArmisCheckpointException(f"Failed to initialize StateManager: {error}")
    
    def _ensure_table_exists(self):
        """Create table if it doesn't exist."""
        try:
            self.table_service_client.create_table(self.table_name)
            applogger.info(f"{self.logs_starts_with} Created checkpoint table: {self.table_name}")
        except ResourceExistsError:
            applogger.debug(f"{self.logs_starts_with} Checkpoint table already exists: {self.table_name}")
        except Exception as error:
            applogger.error(f"{self.logs_starts_with} Failed to create table: {error}")
            raise ArmisCheckpointException(f"Failed to create table: {error}")
    
    def post(self, checkpoint_key: str, checkpoint_data: dict):
        """
        Save checkpoint to Table Storage.
        
        Args:
            checkpoint_key: Unique key for the checkpoint (e.g., 'alerts_last_timestamp')
            checkpoint_data: Dictionary containing checkpoint data
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            entity = {
                "PartitionKey": "ArmisCheckpoint",
                "RowKey": checkpoint_key,
                "CheckpointData": json.dumps(checkpoint_data),
                "LastUpdated": datetime.utcnow().isoformat()
            }
            
            self.table_client.upsert_entity(entity)
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Checkpoint saved successfully for key: {checkpoint_key}"
            )
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to save checkpoint for key {checkpoint_key}: {error}"
            )
            raise ArmisCheckpointException(f"Failed to save checkpoint: {error}")
    
    def get(self, checkpoint_key: str) -> dict:
        """
        Retrieve checkpoint from Table Storage.
        
        Args:
            checkpoint_key: Unique key for the checkpoint
            
        Returns:
            Dictionary containing checkpoint data, or None if not found
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            entity = self.table_client.get_entity(
                partition_key="ArmisCheckpoint",
                row_key=checkpoint_key
            )
            checkpoint_data = json.loads(entity["CheckpointData"])
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Checkpoint retrieved successfully for key: {checkpoint_key}"
            )
            return checkpoint_data
        except ResourceNotFoundError:
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"No checkpoint found for key: {checkpoint_key}"
            )
            return None
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to retrieve checkpoint for key {checkpoint_key}: {error}"
            )
            raise ArmisCheckpointException(f"Failed to retrieve checkpoint: {error}")
    
    def delete(self, checkpoint_key: str):
        """
        Delete checkpoint from Table Storage.
        
        Args:
            checkpoint_key: Unique key for the checkpoint
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.table_client.delete_entity(
                partition_key="ArmisCheckpoint",
                row_key=checkpoint_key
            )
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Checkpoint deleted successfully for key: {checkpoint_key}"
            )
        except ResourceNotFoundError:
            applogger.warning(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Checkpoint not found for deletion: {checkpoint_key}"
            )
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to delete checkpoint for key {checkpoint_key}: {error}"
            )
            raise ArmisCheckpointException(f"Failed to delete checkpoint: {error}")
