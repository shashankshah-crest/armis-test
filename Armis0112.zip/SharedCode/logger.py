"""
Centralized logging configuration for Armis Data Connector.
"""
import logging
import sys
from .consts import LOG_LEVEL, DEFAULT_LOG_LEVEL

# Configure logger
applogger = logging.getLogger("azure")

# Set log level
log_level = LOG_LEVEL.upper()
numeric_level = getattr(logging, log_level, DEFAULT_LOG_LEVEL)
applogger.setLevel(level=numeric_level)

# Configure handler
handler = logging.StreamHandler(stream=sys.stdout)
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
handler.setFormatter(formatter)
applogger.addHandler(handler)


def sanitize_log_message(message: str) -> str:
    """
    Sanitize log messages to remove sensitive information.
    
    Args:
        message: Log message to sanitize
        
    Returns:
        Sanitized log message
    """
    sensitive_keywords = [
        "password", "token", "api_key", "secret", 
        "authorization", "client_secret", "workspace_key"
    ]
    
    sanitized_message = message
    for keyword in sensitive_keywords:
        if keyword.lower() in sanitized_message.lower():
            # Replace sensitive values with asterisks
            sanitized_message = sanitized_message.replace(keyword, "***")
    
    return sanitized_message
