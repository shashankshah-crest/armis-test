"""
Microsoft Sentinel data ingestion using Log Ingestion API.
"""
import json
import inspect
from azure.monitor.ingestion import LogsIngestionClient
from azure.identity import ClientSecretCredential, AzureAuthorityHosts
from azure.core.exceptions import HttpResponseError
from .logger import applogger
from .consts import (
    LOGS_STARTS_WITH,
    AZURE_CLIENT_ID,
    AZURE_CLIENT_SECRET,
    AZURE_TENANT_ID,
    AZURE_DATA_COLLECTION_ENDPOINT,
    SCOPE
)
from .exceptions import ArmisDataIngestionException, ArmisConfigurationException


class MicrosoftSentinel:
    """
    Handles data ingestion to Microsoft Sentinel using Log Ingestion API.
    """
    
    def __init__(self):
        """Initialize Microsoft Sentinel client."""
        self.logs_starts_with = f"{LOGS_STARTS_WITH} MicrosoftSentinel:"
        self._validate_configuration()
        self._ingestion_client = self._create_ingestion_client()
    
    def _validate_configuration(self):
        """Validate required configuration."""
        __method_name = inspect.currentframe().f_code.co_name
        required_vars = {
            "AzureClientId": AZURE_CLIENT_ID,
            "AzureClientSecret": AZURE_CLIENT_SECRET,
            "AzureTenantId": AZURE_TENANT_ID,
            "DataCollectionEndpoint": AZURE_DATA_COLLECTION_ENDPOINT
        }
        
        missing_vars = [key for key, value in required_vars.items() if not value]
        if missing_vars:
            error_msg = f"Missing required environment variables: {', '.join(missing_vars)}"
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) {error_msg}")
            raise ArmisConfigurationException(error_msg)
    
    def _create_ingestion_client(self) -> LogsIngestionClient:
        """
        Create Log Ingestion Client with Gov Cloud support.
        
        Returns:
            LogsIngestionClient instance
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            # Check for Azure Gov Cloud
            if ".us" in SCOPE:
                applogger.info(f"{self.logs_starts_with}(method={__method_name}) Using Azure Gov Cloud")
                credential = ClientSecretCredential(
                    tenant_id=AZURE_TENANT_ID,
                    client_id=AZURE_CLIENT_ID,
                    client_secret=AZURE_CLIENT_SECRET,
                    authority=AzureAuthorityHosts.AZURE_GOVERNMENT
                )
            else:
                applogger.info(f"{self.logs_starts_with}(method={__method_name}) Using Azure Commercial Cloud")
                credential = ClientSecretCredential(
                    tenant_id=AZURE_TENANT_ID,
                    client_id=AZURE_CLIENT_ID,
                    client_secret=AZURE_CLIENT_SECRET
                )
            
            ingestion_client = LogsIngestionClient(
                endpoint=AZURE_DATA_COLLECTION_ENDPOINT,
                credential=credential
            )
            
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Ingestion client created successfully")
            return ingestion_client
            
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to create ingestion client: {error}"
            )
            raise ArmisDataIngestionException(f"Failed to create ingestion client: {error}")
    
    def post_data(self, events: list, table_name: str, dcr_rule_id: str) -> bool:
        """
        Post data to Microsoft Sentinel using Log Ingestion API.
        
        Args:
            events: List of events to ingest
            table_name: Name of the custom table
            dcr_rule_id: Data Collection Rule ID
            
        Returns:
            True if successful, False otherwise
        """
        __method_name = inspect.currentframe().f_code.co_name
        
        if not events:
            applogger.warning(f"{self.logs_starts_with}(method={__method_name}) No events to ingest")
            return True
        
        try:
            dcr_stream_name = f"Custom-{table_name}"
            
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Ingesting {len(events)} events to table: {table_name}"
            )
            
            # Calculate payload size
            payload_size = len(json.dumps(events).encode('utf-8'))
            payload_size_mb = payload_size / (1024 * 1024)
            applogger.debug(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Payload size: {payload_size_mb:.2f} MB"
            )
            
            # Upload data
            self._ingestion_client.upload(
                rule_id=dcr_rule_id,
                stream_name=dcr_stream_name,
                logs=events
            )
            
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Successfully ingested {len(events)} events"
            )
            return True
            
        except HttpResponseError as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"HTTP error during ingestion: Status {error.status_code}, Message: {error.message}"
            )
            raise ArmisDataIngestionException(f"HTTP error during ingestion: {error}")
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to ingest data: {error}"
            )
            raise ArmisDataIngestionException(f"Failed to ingest data: {error}")
    
    def chunk_data(self, data: list, max_size_mb: int = 25) -> list:
        """
        Chunk data into smaller batches based on size limit.
        
        Args:
            data: List of events to chunk
            max_size_mb: Maximum size per chunk in MB
            
        Returns:
            List of chunked data
        """
        __method_name = inspect.currentframe().f_code.co_name
        chunks = []
        current_chunk = []
        current_size = 0
        max_size_bytes = max_size_mb * 1024 * 1024
        
        for item in data:
            item_size = len(json.dumps(item).encode('utf-8'))
            
            if current_size + item_size > max_size_bytes:
                if current_chunk:
                    chunks.append(current_chunk)
                    applogger.debug(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        f"Created chunk with {len(current_chunk)} events, "
                        f"size: {current_size / (1024 * 1024):.2f} MB"
                    )
                current_chunk = [item]
                current_size = item_size
            else:
                current_chunk.append(item)
                current_size += item_size
        
        if current_chunk:
            chunks.append(current_chunk)
            applogger.debug(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Created final chunk with {len(current_chunk)} events, "
                f"size: {current_size / (1024 * 1024):.2f} MB"
            )
        
        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Total chunks created: {len(chunks)}"
        )
        return chunks
