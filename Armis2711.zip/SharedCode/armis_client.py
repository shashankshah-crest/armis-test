"""
Armis API client for fetching alerts data.
"""

import json
import inspect
import requests
from datetime import datetime, timedelta
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    retry_if_result,
)
from .logger import applogger
from .consts import (
    LOGS_STARTS_WITH,
    ARMIS_API_URL,
    ARMIS_API_SECRET_KEY,
    MAX_TIMEOUT,
    MAX_RETRIES,
    RETRY_STATUS_CODES,
    NO_RETRY_STATUS_CODES,
    MAX_PAGE_SIZE,
)
from .exceptions import (
    ArmisAPIAuthenticationException,
    ArmisAPIRateLimitException,
    ArmisAPIRequestException,
    ArmisInvalidResponseException,
    ArmisConfigurationException,
)


class ArmisClient:
    """
    Client for interacting with Armis API.
    """

    def __init__(self):
        """Initialize Armis API client."""
        self.logs_starts_with = f"{LOGS_STARTS_WITH} ArmisClient:"
        self._validate_configuration()
        self.base_url = ARMIS_API_URL.rstrip("/")
        self.api_secret = ARMIS_API_SECRET_KEY
        self.session = self._create_session()
        self.access_token = None

    def _validate_configuration(self):
        """Validate required configuration."""
        __method_name = inspect.currentframe().f_code.co_name
        required_vars = {
            "ArmisAPIURL": ARMIS_API_URL,
            "ArmisAPISecretKey": ARMIS_API_SECRET_KEY,
        }

        missing_vars = [key for key, value in required_vars.items() if not value]
        if missing_vars:
            error_msg = (
                f"Missing required environment variables: {', '.join(missing_vars)}"
            )
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) {error_msg}"
            )
            raise ArmisConfigurationException(error_msg)

    def _create_session(self) -> requests.Session:
        """
        Create requests session with default headers.

        Returns:
            Configured requests.Session
        """
        session = requests.Session()
        session.headers.update(
            {"Content-Type": "application/json", "Accept": "application/json"}
        )
        return session

    def authenticate(self):
        """
        Authenticate with Armis API and obtain access token.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) Authenticating with Armis API"
            )

            auth_url = f"{self.base_url}/api/v1/access_token/"
            payload = {"secret_key": self.api_secret}

            response = self.session.post(auth_url, json=payload, timeout=MAX_TIMEOUT)

            if response.status_code == 200:
                response_data = response.json()
                self.access_token = response_data.get("data", {}).get("access_token")

                if not self.access_token:
                    raise ArmisAPIAuthenticationException(
                        "Access token not found in response"
                    )

                # Update session headers with access token
                self.session.headers.update({"Authorization": self.access_token})

                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) Authentication successful"
                )
            else:
                error_msg = (
                    f"Authentication failed with status code: {response.status_code}"
                )
                applogger.error(
                    f"{self.logs_starts_with}(method={__method_name}) {error_msg}"
                )
                raise ArmisAPIAuthenticationException(error_msg)

        except requests.exceptions.Timeout as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Timeout during authentication: {error}"
            )
            raise requests.exceptions.Timeout(f"Authentication timeout: {error}")
        except requests.exceptions.ConnectionError as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Connection error during authentication: {error}"
            )
            raise requests.exceptions.ConnectionError(
                f"Authentication connection error: {error}"
            )
        except ArmisAPIAuthenticationException:
            raise
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Authentication failed: {error}"
            )
            raise ArmisAPIAuthenticationException(f"Authentication failed: {error}")

    def _should_retry(self, result) -> bool:
        """
        Determine if request should be retried based on status code.

        Args:
            result: Response or status code

        Returns:
            True if should retry, False otherwise
        """
        if isinstance(result, int):
            return result in RETRY_STATUS_CODES
        return False

    def _log_retry_attempt(self, retry_state):
        """Log retry attempt."""
        __method_name = inspect.currentframe().f_code.co_name
        applogger.warning(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Retry attempt {retry_state.attempt_number} after failure"
        )

    def _raise_on_final_failure(self, retry_state):
        """Raise exception on final retry failure."""
        raise ArmisAPIRequestException(
            f"Max retries exceeded: {retry_state.outcome.exception()}"
        )

    @retry(
        reraise=True,
        stop=stop_after_attempt(MAX_RETRIES),
        wait=wait_exponential(multiplier=2, min=5, max=60),
        retry=(
            retry_if_result(lambda x: isinstance(x, int) and x in RETRY_STATUS_CODES)
            | retry_if_exception_type(requests.exceptions.ConnectionError)
            | retry_if_exception_type(requests.exceptions.Timeout)
        ),
        after=lambda retry_state: applogger.warning(
            f"{LOGS_STARTS_WITH} ArmisClient: Retry attempt {retry_state.attempt_number}"
        ),
    )
    def _make_request(
        self, method: str, endpoint: str, params: dict = None, data: dict = None
    ):
        """
        Make HTTP request to Armis API with retry logic.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint
            params: Query parameters
            data: Request body data

        Returns:
            Response JSON or status code for retry
        """
        __method_name = inspect.currentframe().f_code.co_name

        try:
            url = f"{self.base_url}{endpoint}"

            applogger.debug(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Making {method} request to: {endpoint}"
            )

            response = self.session.request(
                method=method, url=url, params=params, json=data, timeout=MAX_TIMEOUT
            )

            # Handle successful response
            if response.status_code == 200:
                return response.json()

            # Handle rate limiting
            elif response.status_code == 429:
                retry_after = response.headers.get("Retry-After", 60)
                applogger.warning(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Rate limit exceeded. Retry after: {retry_after}s"
                )
                return response.status_code

            # Handle retry-able status codes
            elif response.status_code in RETRY_STATUS_CODES:
                applogger.warning(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Received retry-able status code: {response.status_code}"
                )
                return response.status_code

            # Handle non-retry-able status codes
            elif response.status_code in NO_RETRY_STATUS_CODES:
                error_msg = f"Request failed with status {response.status_code}: {response.text}"
                applogger.error(
                    f"{self.logs_starts_with}(method={__method_name}) {error_msg}"
                )
                raise ArmisAPIRequestException(error_msg)

            # Handle unexpected status codes
            else:
                error_msg = (
                    f"Unexpected status code {response.status_code}: {response.text}"
                )
                applogger.error(
                    f"{self.logs_starts_with}(method={__method_name}) {error_msg}"
                )
                raise ArmisAPIRequestException(error_msg)

        except requests.exceptions.Timeout as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Request timeout: {error}"
            )
            raise
        except requests.exceptions.ConnectionError as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Connection error: {error}"
            )
            raise
        except ArmisAPIRequestException:
            raise
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Request failed: {error}"
            )
            raise ArmisAPIRequestException(f"Request failed: {error}")

    def get_alerts(
        self,
        from_time: str = None,
        to_time: str = None,
        aql_filter: str = None,
        max_results: int = None,
    ) -> list:
        """
        Fetch alerts from Armis API.

        Args:
            from_time: Start time in ISO format (e.g., '2024-01-01T00:00:00Z')
            to_time: End time in ISO format
            aql_filter: AQL (Armis Query Language) filter string
            max_results: Maximum number of results to fetch

        Returns:
            List of alert objects
        """
        __method_name = inspect.currentframe().f_code.co_name

        try:
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) Fetching alerts from Armis API"
            )

            # Ensure authentication
            if not self.access_token:
                self.authenticate()

            all_alerts = []
            offset = 0
            page_size = MAX_PAGE_SIZE

            # Build AQL query
            aql_parts = []
            if from_time:
                aql_parts.append(f"time:>{from_time}")
            if to_time:
                aql_parts.append(f"time:<{to_time}")
            if aql_filter:
                aql_parts.append(aql_filter)

            aql_query = " ".join(aql_parts) if aql_parts else None

            while True:
                params = {"length": page_size, "from": offset}

                if aql_query:
                    params["aql"] = aql_query

                # Make request
                response_data = self._make_request(
                    method="GET", endpoint="/api/v1/alerts/", params=params
                )

                # Extract alerts from response
                if not response_data or "data" not in response_data:
                    applogger.warning(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        "Invalid response structure"
                    )
                    break

                alerts = response_data["data"].get("data", [])
                total_count = response_data["data"].get("total", 0)

                if not alerts:
                    applogger.info(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        "No more alerts to fetch"
                    )
                    break

                all_alerts.extend(alerts)

                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Fetched {len(alerts)} alerts (Total: {len(all_alerts)}/{total_count})"
                )

                # Check if we've reached max results
                if max_results and len(all_alerts) >= max_results:
                    all_alerts = all_alerts[:max_results]
                    applogger.info(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        f"Reached max results limit: {max_results}"
                    )
                    break

                # Check if we've fetched all alerts
                if len(all_alerts) >= total_count:
                    applogger.info(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        "Fetched all available alerts"
                    )
                    break

                # Move to next page
                offset += page_size

            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Total alerts fetched: {len(all_alerts)}"
            )

            return all_alerts

        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Failed to fetch alerts: {error}"
            )
            raise ArmisAPIRequestException(f"Failed to fetch alerts: {error}")

    def test_connection(self) -> bool:
        """
        Test connection to Armis API.

        Returns:
            True if connection successful, False otherwise
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.authenticate()
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) Connection test successful"
            )
            return True
        except Exception as error:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Connection test failed: {error}"
            )
            return False
